package inge2.dataflow.zeroanalysis;

/**
 * This enum represents the possible values of the zero analysis for a variable.
 */
public enum ZeroAbstractValue {

    /**
     * We don't have information about the variable.
     */
    BOTTOM("bottom"),

    /**
     * The variable is not zero.
     */
    NOT_ZERO("not-zero"),

    /**
     * The variable is zero.
     */
    ZERO("zero"),

    /**
     * The variable may be (or not) zero.
     */
    MAYBE_ZERO("maybe-zero");

    /**
     * The name of the ZeroAbstractValue.
     */
    private final String name;

    @Override
    public String toString() {
        return this.name;
    }

    ZeroAbstractValue(String name) {
        this.name = name;
    }

    /**
     * Returns the result of the addition between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the addition.
     */
    public ZeroAbstractValue add(ZeroAbstractValue another) {
        if (this.equals(BOTTOM) || another.equals(BOTTOM)) {
            // Si uno de los dos es bottom, la suma da bottom.
            return BOTTOM;
        } else if (this.equals(ZERO)) {
            // Si sumo zero, no cambia el número, por lo que no cambia el estado
            return another;
        } else if (another.equals(ZERO)) {
            // Ídem
            return this;
        } else {
            // Si a un numero que no es zero le sumo zero, o viceversa, no se sabe si es zero o no.
            // Lo mismo pasa si sumas cualquier valor no BOTTOM a un MAYBE ZERO
            return MAYBE_ZERO;
        }
    }

    /**
     * Returns the result of the division between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the division.
     */
    public ZeroAbstractValue divideBy(ZeroAbstractValue another) {
        if (this.equals(BOTTOM) || another.equals(BOTTOM) || another.equals(ZERO)) {
            // Si uno de los operandos es BOTTOM, o el divisor es 0, el resultado es BOTTOM.
            return BOTTOM;
        } else if (this.equals(ZERO)) {
            // 0 dividido por cualquier valor distinto a 0 y BOTTOM, es igual a 0
            return ZERO;
        } else {
            // Si no, no sabemos si el número es 0 o no, ya que al ser división entera, el dividendo no necesita ser 0
            // para que la división sea igual a 0.
            return MAYBE_ZERO;
        }
    }

    /**
     * Returns the result of the multiplication between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the multiplication.
     */
    public ZeroAbstractValue multiplyBy(ZeroAbstractValue another) {
        if (this.equals(BOTTOM) || another.equals(BOTTOM)) {
            // Si cualquiera de los operandos es BOTTOM, el resultado es BOTTOM.
            return BOTTOM;
        } else if (this.equals(ZERO) || another.equals(ZERO)) {
            // Cualquier número no BOTTOM multiplicado por 0 da 0.
            return ZERO;
        } else if (this.equals(MAYBE_ZERO) || another.equals(MAYBE_ZERO)) {
            // Si no sabemos si alguno de los números es 0, el resultado de multiplicarlos peude ser 0 o no.
            return MAYBE_ZERO;
        } else {
            // Si los operandos son distintos de 0, la multiplicación también lo es.
            return NOT_ZERO;
        }
    }

    /**
     * Returns the result of the subtraction between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the subtraction.
     */
    public ZeroAbstractValue subtract(ZeroAbstractValue another) {
        // Restar es lo mismo que sumar con números negativos.
        return add(another);
    }

    /**
     * Returns the result of the merge between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the merge.
     */
    public ZeroAbstractValue merge(ZeroAbstractValue another) {
        if (this.equals(another)) {
            // Si los dos estados son iguales, no se tocan.
            return this;
        } else if (this.equals(BOTTOM)) {
            // La unión entre BOTTOM ({}) y cualquier otro estado es ese otro estado.
            return another;
        } else if (another.equals(BOTTOM)) {
            // Ídem
            return this;
        } else {
            // SI no se cumplieron las condiciones anteriores, solo quedan estos 3 casos:
            //  1. Unión de ZERO y NOT_ZERO: {Z} U {NZ} = {Z, NZ} = MZ
            //  2. Unión de ZERO Y MAYBE_ZERO: {Z} U {MZ} = {Z} U {Z, NZ} = {Z, NZ} = MZ
            //  3. Unión de NOT_ZERO y MAYBE_ZERO: {NZ} U {MZ} = {NZ} U {Z, NZ} = {Z, NZ} = MZ
            return MAYBE_ZERO;
        }
    }

}
